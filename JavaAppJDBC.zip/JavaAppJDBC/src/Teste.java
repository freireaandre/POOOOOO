import java.sql.*;
public class Teste{
    
    public static void main(String[] args)throws SQLException, ClassNotFoundException {
        Connection conection = new ConnectionFactory().getConnection();
        System.out.println("conexão aberta!");
        conection.close();
    
    
    
    
    }
}










































//public class Teste {

 //   public static void main(String[] args) throws SQLExepitions, ClassNotFoundExcetion {
   //     try (Connection = new ConnectionFactory().getConnection()){
     //       System.out.println("conexao aberta");
        }//
       // 
    }//
    //
}//
